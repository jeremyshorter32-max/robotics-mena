ROBOTICS MENA · BRAND KIT
روبوتكس مينا · حزمة الهوية

LOGOS (logos/)
  svg/  Editable vector logos. png/  Ready-to-use exports at 3x (2280x630 for bilingual, 2220x450 for English).
  - logo-bilingual-*      English + Arabic wordmark (primary)
  - logo-english-*        English-only wordmark
  - *-light / *-dark      On the brand's paper (#F7F5EF) or petroleum (#12212B) background
  - *-transparent-for-light-backgrounds / -for-dark-backgrounds   No background, for placing on your own
SYMBOL (symbol/)          The articulated-arm mark alone. Petroleum for light backgrounds, paper for the
                          petroleum background. 1024px transparent PNGs plus SVG.
APP ICONS (app-icons/)    Petroleum and orange square icons, 1024 / 512 / 180 px.
FAVICONS (favicons/)      favicon.ico plus light/dark SVG.
SOCIAL (social/)          1200x630 link previews (English dark, Arabic light).
NEWSLETTER (newsletter/)  1200x320 mastheads (light, dark; light also at 2x).
PATTERN (pattern/)        Mechanical background pattern.
GUIDELINES (guidelines/)  brand-guide.html (open in a browser), design-tokens.css, brand-manifest.json.

COLOURS
  Deep Petroleum  #12212B    Signal Orange   #D65336    Editorial Paper #F7F5EF
  Mineral Teal    #166773    Telemetry Mint  #92D4CB

TYPE
  Brand typeface: 29LT Zarid Sans (commercial licence required, not included). Technical labels: DM Mono.
  The PNG exports and SVG wordmarks use Inter / Noto Sans Arabic as a stand-in. Once Zarid is licensed,
  re-export the wordmarks in Zarid and convert text to outlines before wide distribution.

USE
  Keep clear space around the logo of at least the height of the symbol's inner joint circle x2.
  Do not recolour the symbol outside the palette, stretch it, or add effects.
  Questions: contact@roboticsmena.com
